/**
 * orm 适配层
 */
package com.eliteams.quick4j.core.feature.orm;