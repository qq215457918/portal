/**
 * 功能层
 */
package com.eliteams.quick4j.core.feature;