/**
 *package-info : 缓存插件
 *@since 2015-03-20 11:07
 *@author StarZou
 **/
package com.eliteams.quick4j.core.feature.cache.redis;