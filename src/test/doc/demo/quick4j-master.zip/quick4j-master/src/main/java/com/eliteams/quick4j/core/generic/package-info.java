/**
*通用类层 : generic
*@author StarZou
*@since 2014年5月8日 下午11:04:41
 **/
package com.eliteams.quick4j.core.generic;
