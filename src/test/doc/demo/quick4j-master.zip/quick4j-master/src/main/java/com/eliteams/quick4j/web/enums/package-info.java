/**
 * 枚举类型层
 */
package com.eliteams.quick4j.web.enums;